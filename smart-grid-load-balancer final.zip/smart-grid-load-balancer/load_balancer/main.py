
from flask import Flask, request
import requests
import time

app = Flask(__name__)
SUBSTATIONS = ["http://substation1:5002", "http://substation2:5002"]

def get_load(url):
    try:
        metrics = requests.get(f"{url}/metrics").text
        for line in metrics.splitlines():
            if line.startswith("substation_load"):
                return float(line.split()[-1])
    except Exception:
        return float("inf")
    return float("inf")

@app.route("/route", methods=["POST"])
def route_request():
    data = request.json
    loads = [(url, get_load(url)) for url in SUBSTATIONS]
    loads.sort(key=lambda x: x[1])
    target_url = loads[0][0]
    response = requests.post(f"{target_url}/charge", json=data)
    return response.text, response.status_code

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
