
import requests
import time
import random

URL = "http://localhost:8000/charge"

for _ in range(20):
    data = {"vehicle_id": random.randint(1000, 9999)}
    response = requests.post(URL, json=data)
    print(response.status_code, response.text)
    time.sleep(0.5)
