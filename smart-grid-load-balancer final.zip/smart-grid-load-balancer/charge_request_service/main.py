
from flask import Flask, request
import requests
import os

app = Flask(__name__)
LOAD_BALANCER_URL = os.getenv("LOAD_BALANCER_URL", "http://load_balancer:5001")

@app.route("/charge", methods=["POST"])
def charge_request():
    data = request.json
    response = requests.post(f"{LOAD_BALANCER_URL}/route", json=data)
    return response.text, response.status_code

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5003)
