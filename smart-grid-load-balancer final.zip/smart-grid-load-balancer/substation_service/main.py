
from flask import Flask, request
import random
import threading
import time

app = Flask(__name__)
current_load = 0

@app.route("/charge", methods=["POST"])
def charge():
    global current_load
    current_load += 1
    threading.Thread(target=simulate_charging).start()
    return "Charging started", 200

@app.route("/metrics")
def metrics():
    return f"# HELP substation_load Current load on substation\n# TYPE substation_load gauge\nsubstation_load {current_load}"

def simulate_charging():
    global current_load
    time.sleep(random.randint(2, 5))
    current_load -= 1

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)
